This folder conatins 

1.	All netcdf files for temperature 850 (T850_ddmmyy) and MSLP (MSLP_ddmmyy).
2.	Plots for the time frame 1850's. Eacg plot has MSLP overlayed on Temperature 850. 